豆包输入法助手 · 图标与安装资产包
生成日期：2026-09-17

══════════════════════════════════════════
目录结构
══════════════════════════════════════════
01-AppIcon/
  AppIcon.icns              直接可用的 macOS 应用图标（含 16→1024 全尺寸）
  AppIcon-1024.png          1024×1024 母版（透明背景、已含投影）
  AppIcon.iconset/          10 张标准切图，用于 iconutil 重新打包
  AppIcon.appiconset/       Xcode 资产目录（含 Contents.json），拖进 Assets.xcassets 即可
  AppIcon.svg               矢量源文件，改色/改造型从这里开始
02-MenuBar/
  StatusBarIconTemplate.png / @2x            线框版（推荐，16pt）
  StatusBarIconTemplate-18pt.png / @2x       线框版（18pt）
  StatusBarIconFilledTemplate.png / @2x      实心版（16pt）
  StatusBarIconFilledTemplate-18pt.png / @2x 实心版（18pt）
03-DMG/
  dmg_background.png        660×400，DMG 窗口背景（1x）
  dmg_background@2x.png     1320×800，Retina 背景（2x）
  dmg_background.html       背景源文件，改文案/改配色后重新截图即可
04-Preview/
  preview_1024.png / preview_svg.png / preview_menubar.png  校验用预览

══════════════════════════════════════════
1. 应用图标
══════════════════════════════════════════
Xcode 项目：把 AppIcon.appiconset 拖进 Assets.xcassets，
           Target ▸ General ▸ App Icon 选择 AppIcon。
手工 Bundle：把 AppIcon.icns 放进 YourApp.app/Contents/Resources/，
           Info.plist 增加 <key>CFBundleIconFile</key><string>AppIcon</string>。
在 Mac 上重新打包 icns（改图后）：
  iconutil -c icns AppIcon.iconset -o AppIcon.icns
刷新 Finder 图标缓存：
  touch YourApp.app && killall Finder Dock

══════════════════════════════════════════
2. 菜单栏图标（Template Image）
══════════════════════════════════════════
文件名必须以 Template 结尾，系统才会自动适配浅色/深色菜单栏。
图片本身是纯黑 + Alpha，系统会自动反色，不要手动加白色版本。

Swift（AppKit）：
  let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
  if let button = item.button {
      let image = NSImage(named: "StatusBarIconTemplate")
      image?.isTemplate = true            // 关键
      image?.size = NSSize(width: 16, height: 16)
      button.image = image
  }

SwiftUI（MenuBarExtra）：
  MenuBarExtra { ContentView() } label: {
      Image("StatusBarIconTemplate").renderingMode(.template)
  }

线框版 vs 实心版：线框版更贴近系统风格；如果你的助手有「已激活 / 监听中」状态，
建议 未激活=线框版、激活中=实心版，用同一套形状做状态切换。

══════════════════════════════════════════
3. DMG 安装窗口
══════════════════════════════════════════
窗口尺寸：660 × 400（内容区）
图标中心坐标（以窗口内容区左上角为原点）：
  App 图标          x=170  y=215
  Applications 别名 x=490  y=215
图标大小建议：96 ~ 128 px

合成 Retina 背景（在 Mac 上执行，生成 HiDPI tiff）：
  tiffutil -cathidpicheck dmg_background.png dmg_background@2x.png -out background.tiff

用 create-dmg 一条命令打包（brew install create-dmg）：
  create-dmg \
    --volname "豆包输入法助手" \
    --background "background.tiff" \
    --window-pos 200 120 \
    --window-size 660 400 \
    --icon-size 112 \
    --icon "豆包输入法助手.app" 170 215 \
    --app-drop-link 490 215 \
    --hide-extension "豆包输入法助手.app" \
    --no-internet-enable \
    "豆包输入法助手.dmg" \
    "dist/"

手工方式：新建 DMG ▸ 在窗口内新建隐藏目录 .background ▸ 放入 background.tiff ▸
显示视图选项里选该图作为背景 ▸ 摆好两个图标 ▸ 转为只读压缩镜像。

══════════════════════════════════════════
4. 修改资产
══════════════════════════════════════════
改应用图标造型/配色：编辑 AppIcon.svg，导出 1024×1024 PNG，再切图打包 icns。
改 DMG 文案（例如换正式 App 名）：编辑 dmg_background.html 里的标题与副标题，
用浏览器以 1320×800 截图另存为 @2x，再缩放一份 660×400 作为 1x。

══════════════════════════════════════════
5. 权限提示（这类工具必看）
══════════════════════════════════════════
鼠标侧键映射需要「输入监控」权限，模拟按键/唤起输入法需要「辅助功能」权限，
两者都在 系统设置 ▸ 隐私与安全性 里。未签名分发时，首次打开需右键选「打开」。
上架/公证前请准备开发者 ID 签名与 notarytool 公证流程。
